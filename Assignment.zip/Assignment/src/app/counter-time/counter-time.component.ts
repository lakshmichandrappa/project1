import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-counter-time',
  templateUrl: './counter-time.component.html',
  styleUrls: ['./counter-time.component.css']
})
export class CounterTimeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
