export class GlobalConstants {

    public static products: string[] = [
        'Product1',
        'Product2',
        'Product3', 
        'Product4',
        'Product5',
        'Product6',
        'Product7',
        'Product8',
        'Product9',
        'Product10',
        'Product11',
        'Product12',
        'Product13',
        'Product14',
        'Product15',
        'Product16',
        'Product17',
        'Product18',
        'Product19',
        'Product20'
    ];

    public static studentDetails = [
        {
            Name: 'Max',
            Class: 3,
            Section: 'A',
            Subj1: 85,
            Subj2: 90,
            Subj3: 80
        },
        {
            Name: 'Jhon',
            Class: 4,
            Section: 'B',
            Subj1: 73,
            Subj2: 95,
            Subj3: 81
        },
        {
            Name: 'Akshay',
            Class: 5,
            Section: 'C',
            Subj1: 92,
            Subj2: 72,
            Subj3: 77
        },
        {
            Name: 'Deep',
            Class: 5,
            Section: 'B',
            Subj1: 34,
            Subj2: 89,
            Subj3: 66
        },
        {
            Name: 'Ricky',
            Class: 4,
            Section: 'A',
            Subj1: 90,
            Subj2: 89,
            Subj3: 34
        },
        {
            Name: 'Jack',
            Class: 4,
            Section: 'C',
            Subj1: 45,
            Subj2: 67,
            Subj3: 99
        }
    ]
}